<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ChiTietDonHang extends Model
{
//  protected $table = 'don_hang';
//  protected $primaryKey = 'sanPham_id';
//  protected $fillable = [
//    'ms_dh', 'noiNhan_dh', 'message_dh', 'tongTien_dh', 'khachhang_id',
//  ];

}
