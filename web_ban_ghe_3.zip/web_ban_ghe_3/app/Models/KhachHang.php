<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class KhachHang extends Model
{
  protected $table = 'khach_hang';
  protected $primaryKey = 'id_kh';
  protected $fillable = [
    'ten_kh', 'email_kh', 'diachi_kh', 'sdt_kh',
  ];

  public function donhang(){
    return $this->hasMany(DonHang::class,'khachhang_id','id_kh');
  }
}
