<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Coment extends Model
{
  protected $table = 'coment';
  protected $primaryKey = 'id_cmt';
  protected $fillable = [
    'nickname_cmt', 'email_cmt', 'rating_cmt', 'content_cmt', 'sanpham_id',
  ];

  public function prod() {
    return $this->hasOne(Product::class,'id_sp', 'sanpham_id');
  }
}
