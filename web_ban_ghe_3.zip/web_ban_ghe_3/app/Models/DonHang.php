<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DonHang extends Model
{
  protected $table = 'don_hang';
  protected $primaryKey = 'id_dh';
  protected $fillable = [
    'ms_dh', 'noiNhan_dh', 'message_dh', 'tongTien_dh', 'khachhang_id',
  ];

  public function khachhang() {
    return $this->hasOne(KhachHang::class,'id_kh', 'khachhang_id');
  }
}
