<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
  protected $table = 'san_pham';
  protected $primaryKey = 'id_sp';
  protected $fillable = [
    'ten_sp', 'ms_sp', 'anh_sp', 'list_anh_sp', 'moTa_sp', 'gia_sp', 'giaKM_sp', 'status_sp', 'danhmuc_id',
  ];

  public function cat() {
    return $this->hasOne(Category::class,'id_dm', 'danhmuc_id');
  }

  public function coment() {
    return $this->hasMany(Coment::class,'sanpham_id', 'id_sp');
  }

}
