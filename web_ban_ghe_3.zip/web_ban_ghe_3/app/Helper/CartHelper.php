<?php
namespace App\Helper;

use Session;

class CartHelper {



  public $items = [];
  public $total_quantity = 0;
  public $total_price = 0;

  public function __construct()
  {
    $this->items = session('cart') ? session('cart') : [];
    $this->total_price = $this->get_total_price();
    $this->total_quantity = $this->get_total_quantity();
  }

  public function add($product, $quantity = 1){
    $item = [
      'id_sp' => $product->id_sp,
      'ten_sp' => $product->ten_sp,
      'anh_sp' => $product->anh_sp,
      'gia_sp' => $product->giaKM_sp,
      'so_luong' => $quantity
    ];
    if (isset($this->items[$product->id_sp])){
      $this->items[$product->id_sp]['so_luong'] += $quantity;
    }else {
      $this->items[$product->id_sp] = $item;
    }
//    dd(session('cart'));
    session(['cart' => $this->items]);
  }

  public function remove($id){
    if (isset($this->items[$id])){
      unset($this->items[$id]);
    }

    session(['cart' => $this->items]);
  }

  public function update($id, $quantity){
    if (isset($this->items[$id])){
      $this->items[$id]['so_luong'] = $quantity;
    }

    session(['cart' => $this->items]);
  }

  public function clear(){
    if(Session::has('cart')){
      Session::forget('cart');
    }
  }

  private function get_total_price() {
    $t = 0;
    foreach ($this->items as $item){
      $t += $item['gia_sp']*$item['so_luong'];
    }

    return $t;
  }

  private function get_total_quantity() {
    $t = count($this->items);

    return $t;
  }
}


?>