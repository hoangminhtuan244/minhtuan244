<?php

namespace App\Http\Controllers;

use App\Models\Coment;
use Illuminate\Http\Request;

class ComentController extends Controller
{
    public function add(Request $request, $id){
      $request->offsetUnset('_token');
      $this->validate($request,[
        'nickname_cmt' => 'required',
        'email_cmt' => 'required|email',
        'rating_cmt' => 'required|min:0',
        'content_cmt' => 'required',
      ],[
        'nickname_cmt.required' => 'NickName không được để trống',

        'email_cmt.required' => 'Email không được để trống',
        'email_cmt.email' => 'Email không đúng định dạng (vd: ...@gmail.com)',

        'rating_cmt.required' => 'Hãy chọn rating cho sản phẩm',
        'rating_cmt.min' => 'Đánh giá không thể âm',

        'content_cmt.required' => 'Nội dung coment không được để trống',
      ]);

      $request->merge(['sanpham_id'=>$id]);
      Coment::create($request->all());

      return redirect()->back();
    }
}
