<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Category;

class IndexController extends Controller
{
  public function index()
  {
    $products = Product::paginate(9);
    $cates = Category::all();
    $cate_index = 1;

    $prods_hot = Product::where(['status_sp'=>'Hot'])->paginate(3);
    return view('fontend.home', compact('products', 'cates', 'cate_index', 'prods_hot'));
  }

  public function showProdCate(Request $request){
    $arrCateId = $request->check;
    $products = array();
    foreach ($arrCateId as $id){
      array_push($products,$id);
    }
    $products = Product::whereIn('danhmuc_id',$products)->paginate(9);
    $cates = Category::all();
    $cate_index = 1;
    $prods_hot = Product::where(['status_sp'=>'Hot'])->paginate(3);
    return view('fontend.home', compact('products', 'cates', 'cate_index', 'prods_hot'));
  }

  public function showProdCate_2($id)
  {
    $products = Product::where(['danhmuc_id'=>$id])->paginate(9);
    $cates = Category::all();
    $cate_index = 1;

    $prods_hot = Product::where(['status_sp'=>'Hot'])->paginate(3);
    return view('fontend.home', compact('products', 'cates', 'cate_index', 'prods_hot'));
  }

  public function showLienHe(){
    $cates = Category::all();
    $cate_index = 1;

    $prods_hot = Product::where(['status_sp'=>'Hot'])->paginate(3);
    return view('fontend.lienhe', compact('cates', 'cate_index', 'prods_hot'));
  }

  public function showDieuKhoan(){
    $cates = Category::all();
    $cate_index = 1;

    $prods_hot = Product::where(['status_sp'=>'Hot'])->paginate(3);
    return view('fontend.dieukhoan', compact('cates', 'cate_index', 'prods_hot'));
  }
}
