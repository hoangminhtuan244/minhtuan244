<?php

namespace App\Http\Controllers;

use App\Models\ChiTietDonHang;
use App\Models\DonHang;
use App\Models\KhachHang;
use App\Models\Product;
use Illuminate\Http\Request;
use App\Helper\CartHelper;
use DB;

class CheckOutController extends Controller
{
    function view() {

      return view('fontend.checkout');
    }

    function success(Request $request, CartHelper $cart) {
      $this->validate($request, [
        'ten_kh' => 'required',
        'email_kh' => 'required|email',
        'diachi_kh' => 'required',
        'sdt_kh' => 'required',
        'noiNhan_dh' => 'required',
        'message_dh' => 'required'
      ], [
        'ten_kh.required' => 'Tên không được để trống!',

        'email_kh.required' => 'Email không được để trống!',
        'email_kh.email' => 'Nhập Email hợp lệ (vd: ...@gmail.com)!',

        'diachi_kh.required' => 'Địa chỉ không được để trống!',

        'sdt_kh.required' => 'Số điện thoại không được để trống!',

        'noiNhan_dh.required' => 'Địa chỉ giao hàng không được để trống!',
        'message_dh.required' => 'Ghi chú đơn hàng không được để trống!',
      ]);

      $currentTime = date('Y-m-d H:i:s');

      $khach_hang = new KhachHang;
      $khach_hang->ten_kh = $request->ten_kh;
      $khach_hang->email_kh = $request->email_kh;
      $khach_hang->diachi_kh = $request->diachi_kh;
      $khach_hang->sdt_kh = $request->sdt_kh;
      $khach_hang->updated_at = $currentTime;
      $khach_hang->created_at = $currentTime;
      $khach_hang->save();

      $don_hang = new DonHang;
      $don_hang->ms_dh = uniqid();
      $don_hang->noiNhan_dh = $request->noiNhan_dh;
      $don_hang->message_dh = $request->message_dh;
      $don_hang->tongTien_dh = $cart->total_price;
      $don_hang->khachhang_id = $khach_hang->id_kh;
      $don_hang->updated_at = $currentTime;
      $don_hang->created_at = $currentTime;
      $don_hang->save();

      foreach ($cart->items as $item){
        $prod = Product::find($item['id_sp']);
        DB::table('chi_tiet_don_hang')->insert([
          'sanPham_id' => $prod->id_sp,
          'donHang_id' => $don_hang->id_dh,
          'so_luong' => $item['so_luong'],
          'gia_tien' => $item['gia_sp'],
          'tong_tien' => $item['gia_sp']*$item['so_luong'],
          'updated_at' => $currentTime,
          'created_at' => $currentTime
          ]);

      }

      return redirect()->route('cart.clear');
    }
}
