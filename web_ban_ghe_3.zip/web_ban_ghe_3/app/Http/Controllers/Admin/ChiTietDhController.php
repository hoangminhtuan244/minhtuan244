<?php

namespace App\Http\Controllers\Admin;

use App\Models\ChiTietDonHang;
use App\Models\Product;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;

class ChiTietDhController extends Controller
{


    /**
     * Display the specified resource.
     *
     * @param  \App\Models\ChiTietDonHang  $chiTietDonHang
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $chi_tiets = DB::table('chi_tiet_don_hang')->where('donhang_id',$id)->get();
        // $prod_name = array();

        // for ($i=0; $i < $chi_tiets->count(); $i++) { 
        //     $tmp = DB::table('san_pham')->where(['id_sp'=>$chi_tiets[$i]->sanPham_id])->get();
            
        // }
        
        // dd($prod_name);
        return view('backend.chitietdonhang.index', compact('chi_tiets'));
    }


}
