<?php

namespace App\Http\Controllers\Admin;

use App\Models\Category;
use App\Models\Coment;
use App\Models\Product;
use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Validator;

class UserController extends Controller
{
  /**
   * Display a listing of the resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function index()
  {
    $index = 1;
    $total_prod = Product::all()->count();
    $total_cmt = Coment::all()->count();
    $total_user = User::all()->count();
    $total_cate = Category::all()->count();
    $users = User::paginate(3);
    return view('backend.index', compact('users','index','total_prod','total_cmt','total_user','total_cate'));
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function create()
  {
    return view('backend.admin.addUser');
  }

  /**
   * Store a newly created resource in storage.
   *
   * @param  \Illuminate\Http\Request $request
   * @return \Illuminate\Http\Response
   */
  public function store(Request $request)
  {
    $this->validate($request, [
      'fullname' => 'required',
      'account' => 'required',
      'email' => 'required|email|unique:web_user,email',
      'password' => 'required',
      'confirm_password' => 'required|same:password',
      'level' => 'required'
    ], [
      'fullname.required' => 'Họ và tên không được để trống!',
      'account.required' => 'Tài khoản không được để trống!',
      'email.required' => 'Email không được để trống!',
      'email.email' => 'Email không đúng định dạng! (...@gmail.com)',
      'email.unique' => 'Email này đã được đăng kí!',

      'password.required' => 'Mật khẩu không được để trống!',

      'confirm_password.required' => 'Nhập lại mật khẩu không được để trống!',
      'confirm_password.same' => 'Mật khẩu nhập lại không khớp!',

      'level.required' => 'Level không được để trống!',
    ]);

    $password = bcrypt($request->password);
    $request->merge(['password' => $password]);

    $user = new User;
    $currentTime = date('Y-m-d H:i:s');

    $user->fullName_user = $request->fullname;
    $user->account_user = $request->account;
    $user->email = $request->email;
    $user->password = $request->password;
    $user->level_user = $request->level;
    $user->updated_at = $currentTime;
    $user->created_at = $currentTime;
    $user->save();

    return redirect()->route('user.index');
  }

  /**
   * Display the specified resource.
   *
   * @param  \App\User $user
   * @return \Illuminate\Http\Response
   */
  public function show(User $user)
  {
    //
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  \App\User $user
   * @return \Illuminate\Http\Response
   */
  public function edit($id)
  {
    $user = User::find($id);
    return view('backend.admin.editUser', compact('user'));
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  \Illuminate\Http\Request $request
   * @param  \App\User $user
   * @return \Illuminate\Http\Response
   */
  public function update(Request $request, $id)
  {
    $request->offsetUnset('_token');
    $request->offsetUnset('_method');

    $this->validate($request, [
      'fullname' => 'required',
      'account' => 'required',
      'email' => 'required|email',
      'password' => 'required',
      'confirm_password' => 'required|same:password',
      'level' => 'required'
    ], [
      'fullname.required' => 'Họ và tên không được để trống!',
      'account.required' => 'Tài khoản không được để trống!',
      'email.required' => 'Email không được để trống!',
      'email.email' => 'Email không đúng định dạng! (...@gmail.com)',
      'email.unique' => 'Email này đã được đăng kí!',

      'password.required' => 'Mật khẩu không được để trống!',

      'confirm_password.required' => 'Nhập lại mật khẩu không được để trống!',
      'confirm_password.same' => 'Mật khẩu nhập lại không khớp!',

      'level.required' => 'Level không được để trống!',
    ]);

    $password = bcrypt($request->password);
    $request->merge(['password' => $password]);

    $user = User::find($id);
    $currentTime = date('Y-m-d H:i:s');

    $user->fullName_user = $request->fullname;
    $user->account_user = $request->account;
    $user->email = $request->email;
    $user->password = $request->password;
    $user->level_user = $request->level;
    $user->updated_at = $currentTime;
    $user->created_at = $currentTime;
    $user->save();

    return redirect()->route('user.index');
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  \App\User $user
   * @return \Illuminate\Http\Response
   */
  public function destroy($id)
  {
    User::find($id)->delete();
    return redirect()->back();
  }
}
