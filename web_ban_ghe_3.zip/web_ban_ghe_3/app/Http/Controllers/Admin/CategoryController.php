<?php

namespace App\Http\Controllers\Admin;

use App\Models\Category;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use function Sodium\compare;
use Validator;

class CategoryController extends Controller
{
  /**
   * Display a listing of the resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function index()
  {
    $index = 1;
    $categories = Category::paginate(4);
    return view('backend.category.index', compact('categories','index'));
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function create()
  {
    //
  }

  /**
   * Store a newly created resource in storage.
   *
   * @param  \Illuminate\Http\Request $request
   * @return \Illuminate\Http\Response
   */
  public function store(Request $request)
  {
    $this->validate($request, [
      'name' => 'required|unique:danh_muc,ten_dm',
    ], [
      'name.unique' => 'Tên danh mục đã tồn tại!',
      'name.required' => 'Tên danh mục không được để trống!',
    ]);

    $cate = new Category;
    $currentTime = date('Y-m-d H:i:s');

    $cate->ten_dm = $request->name;
    $cate->updated_at = $currentTime;
    $cate->created_at = $currentTime;
    $cate->save();

    return redirect()->back();
  }

  /**
   * Display the specified resource.
   *
   * @param  \App\Models\Category $categoryModel
   * @return \Illuminate\Http\Response
   */
  public function show(Category $categoryModel)
  {
    //
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  \App\Models\Category $categoryModel
   * @return \Illuminate\Http\Response
   */
  public function edit($id)
  {
    $index = 1;
    $cateEdit = Category::find($id);
    $categories = Category::paginate(4);
    return view('backend.category.index', compact('cateEdit', 'categories','index'));
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  \Illuminate\Http\Request $request
   * @param  \App\Models\Category $categoryModel
   * @return \Illuminate\Http\Response
   */
  public function update(Request $request, $id)
  {
    $request->offsetUnset('_token');
    $request->offsetUnset('_method');

    $this->validate($request, [
      'name' => 'required|unique:danh_muc,ten_dm',
    ], [
      'name.unique' => 'Tên danh mục đã tồn tại!',
      'name.required' => 'Tên danh mục không được để trống!',
    ]);

    $cate = Category::find($id);
    $currentTime = date('Y-m-d H:i:s');

    $cate->ten_dm = $request->name;
    $cate->updated_at = $currentTime;
    $cate->created_at = $currentTime;
    $cate->save();

    return redirect()->route('category.index');
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  \App\Models\Category $categoryModel
   * @return \Illuminate\Http\Response
   */
  public function destroy($id)
  {
    Category::find($id)->delete();
    return redirect()->back();
  }
}
