<?php

namespace App\Http\Controllers\Admin;

use App\Models\Coment;
use App\Models\Product;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ComentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
      $index = 1;
      $coments = Coment::paginate(10);
      return view('backend.coment.index', compact('coments','index'));
    }

  public function show($id)
  {
    $index = 1;
    $prod_name = Product::find($id)->ten_sp;
    $coments = Coment::where(['sanpham_id'=>$id])->orderBy('id_cmt','DESC')->paginate(5);
    return view('backend.coment.index', compact('coments', 'prod_name','index'));
  }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Coment  $coment
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
      Coment::find($id)->delete();
      return redirect()->back();
    }
}
