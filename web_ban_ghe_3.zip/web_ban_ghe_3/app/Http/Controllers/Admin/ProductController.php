<?php

namespace App\Http\Controllers\Admin;

use App\Models\Product;
use App\Models\Category;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
      $index = 1;
      $products = Product::paginate(5);
      return view('backend.product.index', compact('products','index'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
      $cates = Category::all();
        return view('backend.product.addProduct', compact('cates'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      $request->offsetUnset('_token');
      $request->offsetUnset('_method');
      $this->validate($request, [
        'ten_sp' => 'required',
        'ms_sp' => 'required|unique:san_pham,ms_sp',

        'moTa_sp' => 'required',
        'danhmuc_id' => 'required',
        'gia_sp' => 'required|numeric|min:0|not_in:0',
        'giaKM_sp' => 'required|numeric|min:0',
        'status_sp' => 'required',
        'anh_sp' => 'required',
        'list_anh_sp' => 'required',
      ], [
        'ten_sp.required' => 'Tên sản phẩm không được để trống!',
        'ms_sp.required' => 'Mã số không được để trống!',
        'ms_sp.unique' => 'Sản phẩm đã tồn tại! (=>chỉnh sửa sp)',
        'moTa_sp.required' => 'Miêu tả không được để trống!',
        'danhmuc_id.required' => 'Tên danh mục không được để trống!',

        'gia_sp.required' => 'Giá không được để trống!',
        'gia_sp.numeric' => 'Nhập số!',
        'gia_sp.min' => 'Giá phải lớn hơn 0!',
        'gia_sp.not_in' => 'Giá không dược bằng 0!',

        'giaKM_sp.required' => 'Giá KM không được để trống!',
        'giaKM_sp.numeric' => 'Nhập số!',
        'giaKM_sp.min' => 'Giá KM phải lớn hơn 0!',

        'status_sp.required' => 'Chọn trạng thái',
        'anh_sp.required' => 'Chọn ảnh cho sản phẩm!',
        'list_anh_sp.required' => 'Chọn ảnh cho sản phẩm!',
      ]);

      $img = str_replace(url('backend/source').'/', '', $request->anh_sp);
      $img_list = str_replace(url('backend/source').'/', '', $request->list_anh_sp);
//      $img_list_1 = str_replace('[', '', $img_list);
//      $img_list_2 = str_replace('"', '', $img_list_1);
//      $img_list_3 = str_replace(']', '', $img_list_2);
      $currentTime = date('Y-m-d H:i:s');

      $request->merge(['anh_sp' => $img, 'list_anh_sp' => $img_list, 'updated_at' => $currentTime, 'created_at' =>
        $currentTime]);
      Product::create($request->all());

      return redirect()->route('product.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
      $index = 1;
      $cate_name = Category::find($id)->ten_dm;
      $products = Product::where(['danhmuc_id'=>$id])->orderBy('id_sp','DESC')->paginate(5);
      return view('backend.product.index', compact('products','cate_name','index'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
      $prodEdit = Product::find($id);
      $cates = Category::all();
      return view('backend.product.editProduct', compact('prodEdit','cates'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
      $request->offsetUnset('_token');
      $request->offsetUnset('_method');
      $this->validate($request, [
        'ten_sp' => 'required',
        'ms_sp' => 'required',

        'moTa_sp' => 'required',
        'danhmuc_id' => 'required',
        'gia_sp' => 'required|numeric|min:0|not_in:0',
        'giaKM_sp' => 'required|numeric|min:0|lt:gia_sp',
        'status_sp' => 'required',
        'anh_sp' => 'required',
        'list_anh_sp' => 'required',
      ], [
        'ten_sp.required' => 'Tên sản phẩm không được để trống!',
        'ms_sp.required' => 'Mã số không được để trống!',
        'moTa_sp.required' => 'Miêu tả không được để trống!',
        'danhmuc_id.required' => 'Tên danh mục không được để trống!',

        'gia_sp.required' => 'Giá không được để trống!',
        'gia_sp.numeric' => 'Nhập số!',
        'gia_sp.min' => 'Giá phải lớn hơn 0!',
        'gia_sp.not_in' => 'Giá không dược bằng 0!',

        'giaKM_sp.required' => 'Giá KM không được để trống!',
        'giaKM_sp.numeric' => 'Nhập số!',
        'giaKM_sp.min' => 'Giá KM phải lớn hơn 0!',
        'giaKM_sp.lt' => 'Giá KM phải nhỏ hơn giá gốc!',

        'anh_sp.required' => 'Chọn ảnh cho sản phẩm!',
        'list_anh_sp.required' => 'Chọn ảnh cho sản phẩm!',
      ]);

      $img = str_replace(url('backend/source').'/', '', $request->anh_sp);
      $img_list = str_replace(url('backend/source').'/', '', $request->list_anh_sp);
      $img_list_1 = str_replace('[', '', $img_list);
      $img_list_2 = str_replace('"', '', $img_list_1);
      $img_list_3 = str_replace(']', '', $img_list_2);
      $currentTime = date('Y-m-d H:i:s');

      $request->merge(['anh_sp' => $img, 'list_anh_sp' => $img_list_3, 'updated_at' => $currentTime, 'created_at' =>
        $currentTime]);
      Product::where(['id_sp'=>$id])->update($request->all());

      return redirect()->route('product.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
      Product::find($id)->delete();
      return redirect()->back();
    }
}
