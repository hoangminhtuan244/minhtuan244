<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\User;

class LogInController extends Controller
{
  //
  public function getLogin()
  {
    return view('backend.login');
  }

  public function postLogin(Request $request) {
    $request->only('email', 'password', 'remember');

    if($request->remember == "Remember Me"){
      $remember = true;
    }else {
      $remember = false;
    }

    $arr = ['email' => $request->email, 'password' => $request->password];

    if(Auth::attempt($arr,$remember)){
      return redirect()->route('user.index');
    }else {
      return back()->withInput()->with('error','Tài khoản hoặc mật khẩu không đúng');
    }
  }

  public function logout() {
    Auth::logout();
    return redirect()->intended('admin/login');
  }
}
