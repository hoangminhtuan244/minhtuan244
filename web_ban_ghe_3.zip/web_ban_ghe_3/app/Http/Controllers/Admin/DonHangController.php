<?php

namespace App\Http\Controllers\Admin;

use App\Models\DonHang;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class DonHangController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
      $index = 1;
      $don_hangs = DonHang::orderBy('id_dh','DESC')->paginate(5);
      return view('backend.donhang.index', compact('don_hangs','index'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\DonHang  $donHang
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
      DonHang::find($id)->delete();
      return redirect()->back();
    }
}
