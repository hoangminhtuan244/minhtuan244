<?php

namespace App\Http\Controllers;

use App\Models\Coment;
use Illuminate\Http\Request;
use App\Models\Product;

class ProductController extends Controller
{
  public function show($id)
  {
    $product = Product::find($id);
    $image_list = explode(',', $product->list_anh_sp);

    $coments = Coment::where(['sanpham_id'=>$id])->paginate(4);
    $total_coment = Coment::where(['sanpham_id'=>$id])->get();

    $prod_same = Product::where(['danhmuc_id'=>$product->danhmuc_id])->paginate(4);
    
    return view('fontend.product', compact('product', 'prod_same', 'image_list', 'coments'));
  }

}
