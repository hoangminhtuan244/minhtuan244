<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDonHangTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('don_hang', function (Blueprint $table) {
            $table->bigIncrements('id_dh');
          $table->string('ms_dh', 100);
          $table->string('noiNhan_dh', 255);
          $table->text('message_dh');
          $table->bigInteger('tongTien_dh');
          $table->bigInteger('khachhang_id')->unsigned();
          $table->foreign('khachhang_id')->references('id_kh')->on('khach_hang')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('don_hang');
    }
}
