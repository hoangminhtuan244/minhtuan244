<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateComentTable extends Migration
{
  /**
   * Run the migrations.
   *
   * @return void
   */
  public function up()
  {
    Schema::create('coment', function (Blueprint $table) {
      $table->bigIncrements('id_cmt');
      $table->string('nickname_cmt', 100);
      $table->string('email_cmt', 150);
      $table->integer('rating_cmt');
      $table->text('content_cmt');
      $table->bigInteger('sanpham_id')->unsigned();
      $table->foreign('sanpham_id')->references('id_sp')->on('san_pham')->onDelete('cascade');
      $table->timestamps();
    });
  }

  /**
   * Reverse the migrations.
   *
   * @return void
   */
  public function down()
  {
    Schema::dropIfExists('coment');
  }
}
