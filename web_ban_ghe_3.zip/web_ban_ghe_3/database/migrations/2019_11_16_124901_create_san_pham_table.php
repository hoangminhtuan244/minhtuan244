<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSanPhamTable extends Migration
{
  /**
   * Run the migrations.
   *
   * @return void
   */
  public function up()
  {
    Schema::create('san_pham', function (Blueprint $table) {
      $table->bigIncrements('id_sp');
      $table->string('ten_sp', 100);
      $table->string('ms_sp', 150);
      $table->string('anh_sp');
      $table->string('list_anh_sp');
      $table->text('moTa_sp');
      $table->integer('gia_sp');
      $table->integer('giaKM_sp');
      $table->tinyInteger('hot_sp');
      $table->tinyInteger('new_sp');
      $table->bigInteger('danhmuc_id')->unsigned();
      $table->foreign('danhmuc_id')->references('id_dm')->on('danh_muc')->onDelete('cascade');
      $table->timestamps();
    });
  }

  /**
   * Reverse the migrations.
   *
   * @return void
   */
  public function down()
  {
    Schema::dropIfExists('san_pham');
  }
}
