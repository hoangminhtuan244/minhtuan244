<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateChiTietDonHangTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('chi_tiet_don_hang', function (Blueprint $table) {
          $table->unsignedBigInteger('sanPham_id');
          $table->unsignedBigInteger('donHang_id');
          $table->bigInteger('so_luong');
          $table->bigInteger('gia_tien');
          $table->bigInteger('tong_tien');
          $table->primary(array('sanPham_id', 'donHang_id'));
          $table->foreign('sanPham_id')->references('id_sp')->on('san_pham');
          $table->foreign('donHang_id')->references('id_dh')->on('don_hang')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('chi_tiet_don_hang');
    }
}
