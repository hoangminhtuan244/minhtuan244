<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateWebUserTable extends Migration
{
  /**
   * Run the migrations.
   *
   * @return void
   */
  public function up()
  {
    Schema::create('web_user', function (Blueprint $table) {
      $table->bigIncrements('id_user');
      $table->string('fullName_user', 50);
      $table->string('account_user', 50);
      $table->string('email_user', 100);
      $table->string('passworld_user');
      $table->integer('level_user');
      $table->string('remember_token');
      $table->timestamps();
    });
  }

  /**
   * Reverse the migrations.
   *
   * @return void
   */
  public function down()
  {
    Schema::dropIfExists('web_user');
  }
}
